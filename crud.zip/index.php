<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<?php
require_once('layout.php');
?>
<div class="container">
	<center>
	<h1> Search Events by Category </h1>
	</center>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <form action="index.php" class="search-form" method="post">
                <div class="form-group has-feedback">
            		<label for="search" class="sr-only">Search</label>
            		<input type="text" class="form-control" name="search" id="search" placeholder="search">
              		<span class="glyphicon glyphicon-search form-control-feedback"></span>
            	</div>
                    <?php
                        error_reporting(0);
                        include 'config.php';
                        $id_event = $_GET['id_event'];
                        if ($id_event == true) {
                        $sql = "SELECT * from events where id=$id_event";
                        $hasil = $conn->query($sql);
                        $rows = mysqli_fetch_array($hasil);
                        $a = $rows['id'];
                        $b = $rows['nama_event'];
                        $c = $rows['email'];
                        $d = $rows['kategory'];
                        $f = $rows['images'];
                        $g = $rows['url']; 
                        $h = $rows['tgl_event'];
                        $i = $rows['lokasi'];
                        $j = $rows['reg_date'];
                        echo "<center>Event Name : $b</br>
                                    Kategori : $d</br>
                                    Lokasi  : $i</br>
                                    Date & Time : $h </br>
                                    URL : $g </br>
                                    Contact : $c</br>
                                    Register Date : $j</br>
                                    More Events : <a href=\"show.php\">Click</a>
                            </center";

                    }     
                    if(isset($_POST['search'])){
                    $name = $_POST['search'];
                    $no =1;
                    $sql = "SELECT * FROM events WHERE kategory LIKE '$name%'";
                    $result = $conn->query($sql);
                    $hitung = mysqli_num_rows($result);
                    if($hitung == true){
                        echo "      <center>
                                <button type=\"button\" class=\"btn btn-info\">Ditemukan : ".$hitung."
                                </button>
                                </center>";
                                }else {
                                    echo "      <center>
                                <button type=\"button\" class=\"btn btn-info\">Tidak Ditemukan !
                                </button>
                                </center>";
                            }
                    while($row = mysqli_fetch_array($result)){
                        $a = $row['id'];
                        $b = $row['nama_event'];
                        $c = $row['email'];
                        $d = $row['kategory'];
                        $f = $row['images'];
                        $g = $row['url']; 
                        $h = $row['tgl_event'];
                        $i = $row['lokasi'];
                        $j = $row['reg_date'];
                        $no++;
                        if(count($row['kategory']) != 0){
                        echo "<center>Detail Events : <a href=\"index.php?id_event=$a\"> Klik !</a></br>
                                      Nama Events : ".$b."</br>
                                      Kategori :    ".$d."</br>
                                      </center><br><br>";
                    }
                            }
                    
                    }
                    mysqli_close($conn);
                    
                    ?>
            </form>
        </div>
    </div>

</div>


</body> 
</html>
