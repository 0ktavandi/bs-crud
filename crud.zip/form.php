<?php
session_start();
error_reporting(0);
if(!isset($_SESSION['username']) && !isset($_SESSION['password']))  {
header('location: login.php'); 
}
require_once("config.php");
?>
<html lang="en">
<head>
  <title>Create Your Event !</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<?php
require_once('layout.php');
?>
<div class="container">
  <center><h2>Event Generator</h2></center>
  <form class="form-horizontal" action="form.php" method="post" enctype="multipart/form-data">
    <div class="form-group">
      <label class="control-label col-sm-2" for="eventname">Nama Event:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="eventname" placeholder="Enter event name" name="event_name">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="eventdate">Tanggal & Waktu Event:</label>
      <div class="col-sm-10">          
        <input type="datetime-local" class="form-control" id="eventdate" name="date">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="eventdate">Kategori:</label>
      <div class="col-sm-10">          
        <input type="text" class="form-control" id="eventcat" placeholder="Enter kategori" name="cat">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="eventdate">Lokasi:</label>
      <div class="col-sm-10">          
        <input type="text" class="form-control" id="eventloc" placeholder="lokasi" name="loc">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="eventdate">Description:</label>
      <div class="col-sm-10">          
        <input type="text" class="form-control" id="eventdec" name="dec">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="eventdate">URL:</label>
      <div class="col-sm-10">          
        <input type="text" class="form-control" id="eventsrc" placeholder="Enter url" name="url">
      </div>
    </div>

  <div class="form-group">
      <label class="control-label col-sm-2" for="email">Email:</label>
      <div class="col-sm-10">
        <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="cp">Contact Number:</label>
      <div class="col-sm-10">
        <input type="number" class="form-control" id="num" placeholder="Enter phonenumber" name="num">
      </div>
    </div>
  <div class="form-group" >
    <label class="control-label col-sm-2" for="cp">Upload Image Event</label>
    <div class="col-sm-10">
  <input type="file" name="myfile" id="fileToUpload">
  </div>
  </div>
    <div class="form-group" >        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" name="submit" class="btn btn-default">Submit</button>
      </div>
    </div>
  </form>
  <?php
  if(isset($_POST['submit']) && $_POST['event_name'] && $_POST['email'] && $_POST['date'] && $_POST['cat'] && $_POST['loc']){
  $nama = $_FILES['myfile']['name'];
  $event_name = $conn->real_escape_string($_POST['event_name']);
  $waktu = $_POST['date'];
  $lokasi = $_POST['loc'];
  $url = $_POST['url'];
  $dec = $_POST['dec'];
  $category = $_POST['cat'];
  $email = $_POST['email'];
  $file = getimagesize($_FILES['myfile']['tmp_name']);
  $upload_dir = "images";
  if (!$file) {
    print "<center>Are u sure this is image?</center>";
  }else{
    @copy($_FILES['myfile']['tmp_name'],$upload_dir."/".$_FILES['myfile']['name']);
    
  }

 $sql = "INSERT INTO events (nama_event, tgl_event, email,images,kategory,lokasi,url,description)
      VALUES ('{$event_name}','{$waktu}','{$email}','{$nama}','{$category}','{$lokasi}','{$url}','{$dec}')";
   
if ($conn->query($sql) === TRUE) {
    echo "<center><div class=\"alert alert-success\">
      <strong>Success Insert!</strong> " .$upload_dir.'/'.$nama. "
      </div></center>";  
} else {
    echo    '<center><div class="alert alert-danger">
            <strong>'.mysqli_error($conn).'</strong></div>
            </center>' ;
}

mysqli_close($conn);
}else {
      echo  '<center><strong><b>Masukan Semua Data</strong></b></center>' ;
    }
?>
</div>
</body>
</html>