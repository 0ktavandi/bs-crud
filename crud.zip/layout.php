<?php
if(isset($_SESSION['username'])){
  $status = "Logout";
  $link = "login.php?destroy";
}else{
  $status = "Login";
  $link = "login.php";
}
?>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand">Events.id</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="index.php">Home</a></li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Category<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="#">Seminar</a></li>
          <li><a href="#">Workshop</a></li>
          <li><a href="#">M & G</a></li>
        </ul>
      </li>
      <li><a href="form.php">Create Events</a></li>
      <li><a href="show.php">List Events</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="#"><span class="glyphicon glyphicon-user"></span> About</a></li>
      <li><a href="<?php echo $link;?>"><span class="glyphicon glyphicon-log-in"></span>   <?php echo $status;?>   </a></li>
    </ul>
  </div>
</nav>